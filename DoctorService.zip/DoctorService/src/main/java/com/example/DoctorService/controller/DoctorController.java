package com.example.DoctorService.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DoctorController {

    @Value("${server.port}")
    private String port;

    @GetMapping("/doctor")
    public String doctor() {
        return "Doctor service is running on port " + port;
    }
}
